import secrets

sk = secrets.token_hex(24)

print(sk)